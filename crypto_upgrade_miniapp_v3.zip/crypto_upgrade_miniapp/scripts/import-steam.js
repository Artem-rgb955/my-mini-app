/*
 * Импорт скинов CS2 из Steam Community Market в твою базу: реальные цены в рублях + картинки.
 *
 *   npm run import:steam                  — ВСЕ скины (оружие, ножи, перчатки), у которых есть цена в Steam
 *   npm run import:steam -- --max 500     — для проверки: остановиться после 500 предметов
 *   npm run import:steam -- --types rifle,pistol
 *
 * Запускай периодически (раз в сутки), чтобы цены оставались актуальными.
 * Steam ограничивает частоту запросов, поэтому скрипт идёт медленно (пауза STEAM_IMPORT_DELAY_MS)
 * и сам ждёт при ответе 429. Полный импорт — это несколько сотен запросов, займёт 10–30 минут.
 */
require('dotenv').config();
const crypto = require('crypto');
const { Pool } = require('pg');

const arg = name => { const i = process.argv.indexOf('--' + name); return i > -1 ? process.argv[i + 1] : undefined; };
const CURRENCY = Number(process.env.STEAM_CURRENCY || 5); // 5 = RUB
const MIN_PRICE = Number(arg('min') || process.env.MIN_PRICE_KOPEKS || 1);
const DELAY = Number(process.env.STEAM_IMPORT_DELAY_MS || 3500);
const MAX_ITEMS = Number(arg('max') || Infinity);

const TYPE_TAGS = {
  rifle: 'tag_CSGO_Type_Rifle',
  sniper: 'tag_CSGO_Type_SniperRifle',
  pistol: 'tag_CSGO_Type_Pistol',
  smg: 'tag_CSGO_Type_SMG',
  shotgun: 'tag_CSGO_Type_Shotgun',
  machinegun: 'tag_CSGO_Type_Machinegun',
  knife: 'tag_CSGO_Type_Knife',
  gloves: 'tag_Type_Hands'
};
const types = (arg('types') ? arg('types').split(',') : Object.keys(TYPE_TAGS)).map(t => {
  if (!TYPE_TAGS[t]) throw new Error(`Неизвестный тип "${t}". Доступно: ${Object.keys(TYPE_TAGS).join(', ')}`);
  return t;
});

if (!process.env.DATABASE_URL) { console.error('Нет DATABASE_URL в .env'); process.exit(1); }
const pool = new Pool({ connectionString: process.env.DATABASE_URL, ssl: process.env.PGSSL === 'true' ? { rejectUnauthorized: false } : undefined });
const sleep = ms => new Promise(r => setTimeout(r, ms));

async function fetchPage(tag, start, attempt = 0) {
  const url = new URL('https://steamcommunity.com/market/search/render/');
  const p = url.searchParams;
  p.set('query', ''); p.set('start', String(start)); p.set('count', '100');
  p.set('search_descriptions', '0'); p.set('sort_column', 'price'); p.set('sort_dir', 'asc');
  p.set('appid', '730'); p.set('norender', '1'); p.set('l', 'english');
  p.set('currency', String(CURRENCY)); p.set('cc', 'ru'); p.set('country', 'RU');
  p.append('category_730_Type[]', tag);
  const res = await fetch(url, { headers: { 'User-Agent': 'Mozilla/5.0 (CryptoUpgradeImporter)', Accept: 'application/json' } });
  if (res.status === 429 || res.status >= 500) {
    if (attempt >= 6) throw new Error(`Steam отвечает ${res.status}. Подожди 10–20 минут и запусти снова (уже загруженное сохранено).`);
    const wait = 60000 * (attempt + 1);
    console.log(`  Steam ${res.status} — жду ${wait / 1000} с…`);
    await sleep(wait);
    return fetchPage(tag, start, attempt + 1);
  }
  if (!res.ok) throw new Error(`Steam вернул HTTP ${res.status}`);
  const data = await res.json();
  if (!data || data.success === false) throw new Error('Steam вернул неуспешный ответ');
  return data;
}

const GRADE_SUFFIX = /\s+(Sniper Rifle|Rifle|Pistol|SMG|Shotgun|Machinegun|Knife|Gloves)$/i;
function mapItem(x) {
  const hash = String(x.hash_name || x.name || '');
  const [weapon, ...rest] = hash.split(' | ');
  const icon = x.asset_description?.icon_url || '';
  const type = String(x.asset_description?.type || '');
  return {
    id: 's_' + crypto.createHash('sha1').update(hash).digest('hex').slice(0, 20),
    name: String(x.name || hash),
    weapon: weapon || hash,
    skin: rest.join(' | ') || hash,
    price: Number(x.sell_price || 0),
    image: icon ? `https://community.akamai.steamstatic.com/economy/image/${icon}/256fx256f` : '',
    rarity: type.replace(GRADE_SUFFIX, '').trim() || 'Steam',
    hash,
    url: `https://steamcommunity.com/market/listings/730/${encodeURIComponent(hash)}`,
    listings: Number(x.sell_listings || 0),
    priceText: String(x.sell_price_text || '')
  };
}

async function save(rows) {
  if (!rows.length) return;
  await pool.query(
    `INSERT INTO items (id,name,weapon,skin,price_cents,image_url,rarity,market_hash_name,market_url,listings,is_demo,updated_at)
     SELECT id,name,weapon,skin,price,image,rarity,hash,url,listings,FALSE,NOW()
     FROM unnest($1::text[],$2::text[],$3::text[],$4::text[],$5::int[],$6::text[],$7::text[],$8::text[],$9::text[],$10::int[])
       AS t(id,name,weapon,skin,price,image,rarity,hash,url,listings)
     ON CONFLICT (id) DO UPDATE SET price_cents=EXCLUDED.price_cents, image_url=EXCLUDED.image_url,
       rarity=EXCLUDED.rarity, listings=EXCLUDED.listings, market_url=EXCLUDED.market_url, is_demo=FALSE, updated_at=NOW()`,
    [rows.map(r => r.id), rows.map(r => r.name), rows.map(r => r.weapon), rows.map(r => r.skin), rows.map(r => r.price),
     rows.map(r => r.image), rows.map(r => r.rarity), rows.map(r => r.hash), rows.map(r => r.url), rows.map(r => r.listings)]
  );
}

(async () => {
  let total = 0, checkedCurrency = false;
  const seen = new Set();
  console.log(`Импорт: типы=${types.join(', ')}, минимум=${(MIN_PRICE / 100).toFixed(2)} ₽, валюта=${CURRENCY}`);
  for (const type of types) {
    const tag = TYPE_TAGS[type];
    let start = 0, totalCount = Infinity;
    console.log(`\n== ${type} ==`);
    while (start < totalCount && total < MAX_ITEMS) {
      const data = await fetchPage(tag, start);
      totalCount = Number(data.total_count || 0);
      const rows = [];
      for (const raw of data.results || []) {
        const it = mapItem(raw);
        if (!checkedCurrency && it.priceText) {
          // Защита: если Steam отдал не рубли — не пишем в базу неверные цены.
          if (!/руб|₽|RUB/i.test(it.priceText)) {
            throw new Error(`Steam отдаёт цены не в рублях ("${it.priceText}"). Цены не сохранены. Запусти импорт с российским IP/VPN или из аккаунта с рублёвым кошельком.`);
          }
          checkedCurrency = true;
        }
        if (it.price < MIN_PRICE || !it.hash || seen.has(it.hash)) continue;
        seen.add(it.hash);
        rows.push(it);
      }
      await save(rows);
      total += rows.length;
      console.log(`  ${Math.min(start + 100, totalCount)}/${totalCount} просмотрено, сохранено всего: ${total}`);
      start += 95; // небольшой нахлёст: цены сдвигаются между запросами
      await sleep(DELAY);
    }
  }
  console.log(`\nГотово. В каталоге обновлено предметов: ${total}`);
  await pool.end();
})().catch(async e => { console.error('\nОшибка:', e.message); await pool.end().catch(() => {}); process.exit(1); });
